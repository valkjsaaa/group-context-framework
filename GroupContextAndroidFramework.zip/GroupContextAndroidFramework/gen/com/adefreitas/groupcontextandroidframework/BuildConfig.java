/** Automatically generated file. DO NOT MODIFY */
package com.adefreitas.groupcontextandroidframework;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}